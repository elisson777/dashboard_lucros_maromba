import type { Campaign, DashboardKpis } from "./sheets";

const currency = new Intl.NumberFormat("pt-BR", {
  style: "currency",
  currency: "BRL",
  minimumFractionDigits: 2,
  maximumFractionDigits: 2,
});
const percent = new Intl.NumberFormat("pt-BR", { maximumFractionDigits: 1 });

function download(blob: Blob, filename: string) {
  const url = URL.createObjectURL(blob);
  const anchor = document.createElement("a");
  anchor.href = url;
  anchor.download = filename;
  anchor.click();
  window.setTimeout(() => URL.revokeObjectURL(url), 1000);
}

function dateStamp() {
  return new Date().toISOString().slice(0, 10);
}

function escapeCsvCell(value: string | number) {
  const cell = String(value);
  return `"${cell.replace(/"/g, '""')}"`;
}

export function exportCampaignCsv(campaigns: Campaign[]) {
  if (campaigns.length === 0) return;
  const headers = Object.keys(campaigns[0].raw);
  const lines = [
    headers.map(escapeCsvCell).join(";"),
    ...campaigns.map(campaign =>
      headers.map(header => escapeCsvCell(campaign.raw[header] ?? "")).join(";")
    ),
  ];
  const blob = new Blob(["\uFEFF", lines.join("\r\n")], {
    type: "text/csv;charset=utf-8",
  });
  download(blob, `campanhas-marketing-${dateStamp()}.csv`);
}

function excelValue(header: string, rawValue: string) {
  const numericHeaders = new Set([
    "Cliques no Link",
    "Pedidos Realizados",
    "Taxa de Conversão",
    "Unidades Vendidas",
    "Faturamento Bruto (R$)",
    "Ticket Médio (R$)",
    "Impostos e Taxas (R$)",
    "Faturamento Líquido (R$)",
    "Cachê Influenciador (R$)",
    "Produtos Enviados (R$)",
    "Custos de Produção (R$)",
    "% Comissão",
    "Comissão Paga (R$)",
    "Investimento Total (R$)",
    "Lucro Líquido (R$)",
    "ROAS (x)",
    "ROI Líquido (%)",
  ]);
  if (!numericHeaders.has(header)) return rawValue;

  const cleaned = rawValue.trim().replace(/[R$%xX\s\u00a0]/g, "");
  const parsed = Number.parseFloat(
    cleaned.includes(",")
      ? cleaned.replace(/\./g, "").replace(",", ".")
      : cleaned.replace(/\./g, "")
  );
  if (!Number.isFinite(parsed)) return 0;
  if (
    header === "Taxa de Conversão" ||
    header === "% Comissão" ||
    header === "ROI Líquido (%)"
  ) {
    return parsed / 100;
  }
  return parsed;
}

export function exportCampaignXlsx(campaigns: Campaign[], kpis: DashboardKpis) {
  if (campaigns.length === 0) return;
  return import("xlsx").then(XLSX => {
    const headers = Object.keys(campaigns[0].raw);
    const campaignRows = campaigns.map(campaign =>
      Object.fromEntries(
        headers.map(header => [
          header,
          excelValue(header, campaign.raw[header] ?? ""),
        ])
      )
    );
    const workbook = XLSX.utils.book_new();
    const detailSheet = XLSX.utils.json_to_sheet(campaignRows, {
      header: headers,
    });
    detailSheet["!cols"] = headers.map(header => ({
      wch: Math.min(34, Math.max(14, header.length + 3)),
    }));
    XLSX.utils.book_append_sheet(workbook, detailSheet, "Campanhas");

    const summaryRows = [
      ["Indicador", "Valor"],
      ["Campanhas no filtro", kpis.campaigns],
      ["Faturamento bruto", kpis.grossRevenue],
      ["Faturamento líquido", kpis.netRevenue],
      ["Investimento total", kpis.investment],
      ["Lucro líquido", kpis.netProfit],
      ["ROAS consolidado", kpis.roas],
      ["ROI líquido (%)", kpis.roiPercent / 100],
      ["Cliques no link", kpis.clicks],
      ["Pedidos realizados", kpis.orders],
      ["Conversão (%)", kpis.conversionRate / 100],
      ["Ticket médio", kpis.averageTicket],
    ];
    const summarySheet = XLSX.utils.aoa_to_sheet(summaryRows);
    summarySheet["!cols"] = [{ wch: 28 }, { wch: 24 }];
    XLSX.utils.book_append_sheet(workbook, summarySheet, "Resumo");
    const output = XLSX.write(workbook, { bookType: "xlsx", type: "array" });
    download(
      new Blob([output], {
        type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
      }),
      `campanhas-marketing-${dateStamp()}.xlsx`
    );
  });
}

function shorten(value: string, limit: number) {
  return value.length > limit ? `${value.slice(0, limit - 1)}…` : value;
}

export function exportCampaignPdf(campaigns: Campaign[], kpis: DashboardKpis) {
  if (campaigns.length === 0) return;
  return import("jspdf").then(({ jsPDF }) => {
    const doc = new jsPDF({
      orientation: "landscape",
      unit: "mm",
      format: "a4",
    });
    const pageWidth = doc.internal.pageSize.getWidth();
    const pageHeight = doc.internal.pageSize.getHeight();
    const left = 12;
    const right = pageWidth - 12;

    doc.setFillColor(15, 45, 43);
    doc.rect(0, 0, pageWidth, 47, "F");
    doc.setTextColor(185, 235, 117);
    doc.setFont("helvetica", "bold");
    doc.setFontSize(8);
    doc.text("VISÃO EXECUTIVA  /  MARKETING DE INFLUÊNCIA", left, 11);
    doc.setTextColor(255, 255, 255);
    doc.setFontSize(20);
    doc.text("Resultado das campanhas", left, 22);
    doc.setFont("helvetica", "normal");
    doc.setTextColor(215, 229, 224);
    doc.setFontSize(8);
    doc.text(
      `${kpis.campaigns} campanhas no recorte  ·  Gerado em ${new Date().toLocaleString("pt-BR")}`,
      left,
      30
    );

    const metricItems = [
      ["FATURAMENTO BRUTO", currency.format(kpis.grossRevenue)],
      ["INVESTIMENTO", currency.format(kpis.investment)],
      ["LUCRO LÍQUIDO", currency.format(kpis.netProfit)],
      [
        "ROAS",
        `${kpis.roas.toLocaleString("pt-BR", { maximumFractionDigits: 2 })}x`,
      ],
      ["ROI LÍQUIDO", `${percent.format(kpis.roiPercent)}%`],
    ];
    const metricWidth = (right - left) / metricItems.length;
    metricItems.forEach(([label, value], index) => {
      const x = left + index * metricWidth;
      doc.setTextColor(177, 199, 190);
      doc.setFontSize(6.5);
      doc.setFont("helvetica", "bold");
      doc.text(label, x, 39);
      doc.setTextColor(255, 255, 255);
      doc.setFontSize(10);
      doc.text(value, x, 44);
    });

    const columns = [
      { title: "ID", width: 12, value: (c: Campaign) => c.id },
      {
        title: "Influenciador",
        width: 38,
        value: (c: Campaign) => shorten(c.influencer, 30),
      },
      {
        title: "Campanha",
        width: 54,
        value: (c: Campaign) => shorten(c.campaign, 46),
      },
      {
        title: "Formato",
        width: 39,
        value: (c: Campaign) => shorten(c.format, 31),
      },
      {
        title: "Faturamento",
        width: 31,
        value: (c: Campaign) => currency.format(c.grossRevenue),
      },
      {
        title: "Investimento",
        width: 31,
        value: (c: Campaign) => currency.format(c.investment),
      },
      {
        title: "Lucro líquido",
        width: 31,
        value: (c: Campaign) => currency.format(c.netProfit),
      },
      {
        title: "ROAS",
        width: 17,
        value: (c: Campaign) =>
          `${c.roas.toLocaleString("pt-BR", { maximumFractionDigits: 2 })}x`,
      },
      {
        title: "ROI",
        width: 19,
        value: (c: Campaign) => `${percent.format(c.roiPercent)}%`,
      },
    ];
    const tableWidth = columns.reduce((sum, column) => sum + column.width, 0);

    const drawTableHeader = (y: number) => {
      doc.setFillColor(235, 241, 236);
      doc.rect(left, y - 5.5, tableWidth, 8, "F");
      doc.setFont("helvetica", "bold");
      doc.setFontSize(7);
      doc.setTextColor(49, 70, 64);
      let x = left + 1.5;
      columns.forEach(column => {
        doc.text(column.title, x, y);
        x += column.width;
      });
    };

    let y = 57;
    drawTableHeader(y);
    y += 8;
    doc.setFont("helvetica", "normal");
    doc.setFontSize(6.5);

    campaigns.forEach((campaign, rowIndex) => {
      if (y > pageHeight - 13) {
        doc.addPage("a4", "landscape");
        y = 17;
        drawTableHeader(y);
        y += 8;
      }
      if (rowIndex % 2 === 0) {
        doc.setFillColor(249, 251, 248);
        doc.rect(left, y - 4.8, tableWidth, 7, "F");
      }
      let x = left + 1.5;
      columns.forEach(column => {
        doc.setTextColor(42, 56, 51);
        doc.text(column.value(campaign), x, y, { maxWidth: column.width - 3 });
        x += column.width;
      });
      y += 7;
    });

    const pages = doc.getNumberOfPages();
    for (let page = 1; page <= pages; page += 1) {
      doc.setPage(page);
      doc.setFont("helvetica", "normal");
      doc.setFontSize(7);
      doc.setTextColor(120, 136, 129);
      doc.text(
        "Fonte: planilha publicada do Google Sheets  ·  Valores em reais",
        left,
        pageHeight - 6
      );
      doc.text(`${page} / ${pages}`, right, pageHeight - 6, { align: "right" });
    }

    doc.save(`relatorio-campanhas-${dateStamp()}.pdf`);
  });
}
