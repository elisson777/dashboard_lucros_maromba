const SPREADSHEET_ID = "1myBd8o1ZlVuwcobC_VdofVEW0nDftDj4m4GmVkGpttw";
export const SHEET_URL = `https://docs.google.com/spreadsheets/d/${SPREADSHEET_ID}/edit`;

const CSV_URL = `https://docs.google.com/spreadsheets/d/${SPREADSHEET_ID}/export?format=csv&gid=0`;

export type Campaign = {
  id: string;
  influencer: string;
  profile: string;
  format: string;
  campaign: string;
  period: string;
  gym: string;
  brand: string;
  clicks: number;
  orders: number;
  conversionRate: number;
  units: number;
  grossRevenue: number;
  averageTicket: number;
  taxes: number;
  netRevenue: number;
  influencerFee: number;
  productsCost: number;
  productionCost: number;
  commissionRate: number;
  commissionPaid: number;
  investment: number;
  netProfit: number;
  roas: number;
  roiPercent: number;
  recommendation: string;
  raw: Record<string, string>;
};

export type DashboardKpis = {
  campaigns: number;
  clicks: number;
  orders: number;
  units: number;
  grossRevenue: number;
  netRevenue: number;
  investment: number;
  netProfit: number;
  roas: number;
  roiPercent: number;
  conversionRate: number;
  averageTicket: number;
};

export type CampaignGroup = {
  name: string;
  campaigns: number;
  clicks: number;
  orders: number;
  grossRevenue: number;
  investment: number;
  netProfit: number;
  roas: number;
  roiPercent: number;
  conversionRate: number;
};

/** CSV parser that preserves commas and line breaks inside quoted cells. */
export function parseCsv(input: string): string[][] {
  const rows: string[][] = [];
  let row: string[] = [];
  let cell = "";
  let quoted = false;

  for (let index = 0; index < input.length; index += 1) {
    const character = input[index];

    if (quoted) {
      if (character === '"' && input[index + 1] === '"') {
        cell += '"';
        index += 1;
      } else if (character === '"') {
        quoted = false;
      } else {
        cell += character;
      }
      continue;
    }

    if (character === '"') {
      quoted = true;
    } else if (character === ",") {
      row.push(cell);
      cell = "";
    } else if (character === "\n") {
      row.push(cell.replace(/\r$/, ""));
      rows.push(row);
      row = [];
      cell = "";
    } else if (character !== "\r") {
      cell += character;
    }
  }

  if (cell.length > 0 || row.length > 0) {
    row.push(cell.replace(/\r$/, ""));
    rows.push(row);
  }

  return rows;
}

/** Google Sheets publishes Brazilian numeric values with decimal commas and thousands dots. */
export function parseBrazilianNumber(value: string | undefined): number {
  if (!value) return 0;
  const trimmed = value.trim();
  if (!trimmed || trimmed === "—" || trimmed === "-") return 0;

  const negativeByParentheses = /^\(.*\)$/.test(trimmed);
  const cleaned = trimmed.replace(/[R$%xX\s\u00a0]/g, "").replace(/[()]/g, "");
  const normalized = cleaned.includes(",")
    ? cleaned.replace(/\./g, "").replace(",", ".")
    : cleaned.replace(/\./g, "");
  const parsed = Number.parseFloat(normalized);
  if (!Number.isFinite(parsed)) return 0;
  return negativeByParentheses ? -Math.abs(parsed) : parsed;
}

function field(row: Record<string, string>, header: string): string {
  return (row[header] ?? "").trim();
}

export function displayPeriod(value: string): string {
  const match = value.match(/\(([^()]*)\)\s*$/);
  return match?.[1]?.trim() || value.trim();
}

function toCampaign(row: Record<string, string>): Campaign {
  return {
    id: field(row, "ID Campanha"),
    influencer: field(row, "Influenciador"),
    profile: field(row, "Perfil / Categoria"),
    format: field(row, "Canal / Formato"),
    campaign: field(row, "Campanha"),
    period: field(row, "Mês / Período"),
    gym: field(row, "Rede de Academias Frequentada"),
    brand: field(row, "Marca / Linha Mais Usada"),
    clicks: parseBrazilianNumber(row["Cliques no Link"]),
    orders: parseBrazilianNumber(row["Pedidos Realizados"]),
    conversionRate: parseBrazilianNumber(row["Taxa de Conversão"]) / 100,
    units: parseBrazilianNumber(row["Unidades Vendidas"]),
    grossRevenue: parseBrazilianNumber(row["Faturamento Bruto (R$)"]),
    averageTicket: parseBrazilianNumber(row["Ticket Médio (R$)"]),
    taxes: parseBrazilianNumber(row["Impostos e Taxas (R$)"]),
    netRevenue: parseBrazilianNumber(row["Faturamento Líquido (R$)"]),
    influencerFee: parseBrazilianNumber(row["Cachê Influenciador (R$)"]),
    productsCost: parseBrazilianNumber(row["Produtos Enviados (R$)"]),
    productionCost: parseBrazilianNumber(row["Custos de Produção (R$)"]),
    commissionRate: parseBrazilianNumber(row["% Comissão"]) / 100,
    commissionPaid: parseBrazilianNumber(row["Comissão Paga (R$)"]),
    investment: parseBrazilianNumber(row["Investimento Total (R$)"]),
    netProfit: parseBrazilianNumber(row["Lucro Líquido (R$)"]),
    roas: parseBrazilianNumber(row["ROAS (x)"].replace(/x/gi, "")),
    roiPercent: parseBrazilianNumber(row["ROI Líquido (%)"]),
    recommendation: field(row, "Decisão Recomendada"),
    raw: row,
  };
}

export function parseCampaignCsv(csv: string): Campaign[] {
  const rows = parseCsv(csv.replace(/^\uFEFF/, ""));
  const headerIndex = rows.findIndex(row =>
    row.some(cell => cell.trim() === "ID Campanha")
  );
  if (headerIndex < 0) {
    throw new Error("A aba de campanhas não contém o cabeçalho 'ID Campanha'.");
  }

  const headers = rows[headerIndex].map(header => header.trim());
  const required = [
    "ID Campanha",
    "Influenciador",
    "Faturamento Bruto (R$)",
    "Investimento Total (R$)",
    "Lucro Líquido (R$)",
    "ROAS (x)",
    "ROI Líquido (%)",
  ];
  const missing = required.filter(header => !headers.includes(header));
  if (missing.length > 0) {
    throw new Error(
      `A planilha mudou de estrutura. Colunas ausentes: ${missing.join(", ")}.`
    );
  }

  return rows
    .slice(headerIndex + 1)
    .filter(cells => cells[0]?.trim().startsWith("CMP-"))
    .map(cells => {
      const raw: Record<string, string> = {};
      headers.forEach((header, index) => {
        if (header) raw[header] = (cells[index] ?? "").trim();
      });
      return toCampaign(raw);
    });
}

export async function fetchCampaigns(
  signal?: AbortSignal
): Promise<Campaign[]> {
  const separator = CSV_URL.includes("?") ? "&" : "?";
  const response = await fetch(`${CSV_URL}${separator}_=${Date.now()}`, {
    cache: "no-store",
    signal,
  });

  if (!response.ok) {
    throw new Error(`O Google Sheets respondeu com status ${response.status}.`);
  }

  const contentType = response.headers.get("content-type") ?? "";
  const csv = await response.text();
  if (!contentType.includes("csv") || !csv.includes("ID Campanha")) {
    throw new Error(
      "A planilha não retornou um CSV legível. Confira se o acesso de leitor está ativo."
    );
  }

  const campaigns = parseCampaignCsv(csv);
  if (campaigns.length === 0) {
    throw new Error(
      "A planilha foi carregada, mas não contém campanhas válidas."
    );
  }
  return campaigns;
}

export function calculateKpis(campaigns: Campaign[]): DashboardKpis {
  const totals = campaigns.reduce(
    (sum, campaign) => ({
      clicks: sum.clicks + campaign.clicks,
      orders: sum.orders + campaign.orders,
      units: sum.units + campaign.units,
      grossRevenue: sum.grossRevenue + campaign.grossRevenue,
      netRevenue: sum.netRevenue + campaign.netRevenue,
      investment: sum.investment + campaign.investment,
      netProfit: sum.netProfit + campaign.netProfit,
    }),
    {
      clicks: 0,
      orders: 0,
      units: 0,
      grossRevenue: 0,
      netRevenue: 0,
      investment: 0,
      netProfit: 0,
    }
  );

  return {
    campaigns: campaigns.length,
    ...totals,
    roas: totals.investment > 0 ? totals.grossRevenue / totals.investment : 0,
    roiPercent:
      totals.investment > 0 ? (totals.netProfit / totals.investment) * 100 : 0,
    conversionRate:
      totals.clicks > 0 ? (totals.orders / totals.clicks) * 100 : 0,
    averageTicket: totals.orders > 0 ? totals.grossRevenue / totals.orders : 0,
  };
}

export function groupCampaigns(
  campaigns: Campaign[],
  groupBy: "format" | "gym" | "profile" | "brand" | "influencer" | "period"
): CampaignGroup[] {
  const groups = new Map<string, Campaign[]>();
  for (const campaign of campaigns) {
    const name = campaign[groupBy] || "Não informado";
    groups.set(name, [...(groups.get(name) ?? []), campaign]);
  }

  return Array.from(groups, ([name, members]) => {
    const clicks = members.reduce((sum, member) => sum + member.clicks, 0);
    const orders = members.reduce((sum, member) => sum + member.orders, 0);
    const grossRevenue = members.reduce(
      (sum, member) => sum + member.grossRevenue,
      0
    );
    const investment = members.reduce(
      (sum, member) => sum + member.investment,
      0
    );
    const netProfit = members.reduce(
      (sum, member) => sum + member.netProfit,
      0
    );
    return {
      name,
      campaigns: members.length,
      clicks,
      orders,
      grossRevenue,
      investment,
      netProfit,
      roas: investment > 0 ? grossRevenue / investment : 0,
      roiPercent: investment > 0 ? (netProfit / investment) * 100 : 0,
      conversionRate: clicks > 0 ? (orders / clicks) * 100 : 0,
    };
  });
}
