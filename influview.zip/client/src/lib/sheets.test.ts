import { describe, expect, it } from "vitest";
import {
  calculateKpis,
  parseBrazilianNumber,
  parseCampaignCsv,
  parseCsv,
} from "./sheets";

const sampleCsv = `BASE DE CAMPANHAS,,,,,,,
Monitoramento de campanhas,,,,,,,
,,,,,,,
ID Campanha,Influenciador,Perfil / Categoria,Canal / Formato,Campanha,Rede de Academias Frequentada,Marca / Linha Mais Usada,Cliques no Link,Pedidos Realizados,Taxa de Conversão,Unidades Vendidas,Faturamento Bruto (R$),Ticket Médio (R$),Impostos e Taxas (R$),Faturamento Líquido (R$),Cachê Influenciador (R$),Produtos Enviados (R$),Custos de Produção (R$),% Comissão,Comissão Paga (R$),Investimento Total (R$),Lucro Líquido (R$),ROAS (x),ROI Líquido (%),Decisão Recomendada
CMP-01,Criador Um,Categoria,Vídeo Solo,"Campanha, especial",Rede,Marca,28.000,1.176,"4,20%",2.705,"R$ 329.280,00","R$ 280,00","R$ 39.513,60","R$ 289.766,40","R$ 55.000,00","R$ 4.500,00","R$ 8.000,00","5,0%","R$ 14.488,32","R$ 81.988,32","R$ 207.778,08","4,02x","253,4%",Manter / Renovar
CMP-02,Criador Dois,Categoria,Afiliado Link,Outra campanha,Rede Dois,Marca Dois,1.000,20,"2,00%",35,"R$ 10.000,00","R$ 500,00","R$ 1.000,00","R$ 9.000,00","R$ 2.000,00","R$ 0,00","R$ 0,00","10,0%","R$ 1.000,00","R$ 3.000,00","R$ 1.000,00","3,33x","33,3%",Escalar
TOTAL / MÉDIA,Consolidado,,,,,,,,,,,,,,,,,,,,,,,,`;

describe("formatação e leitura dos dados da planilha", () => {
  it("interpreta milhares, casas decimais e valores negativos brasileiros", () => {
    expect(parseBrazilianNumber("200.500")).toBe(200500);
    expect(parseBrazilianNumber("R$ 1.962.302,00")).toBe(1962302);
    expect(parseBrazilianNumber("-R$ 13.272,16")).toBe(-13272.16);
    expect(parseBrazilianNumber("253,4%")).toBe(253.4);
  });

  it("preserva vírgulas dentro de campos CSV entre aspas", () => {
    expect(parseCsv('CMP-01,"Criador, Especial",Campanha')).toEqual([
      ["CMP-01", "Criador, Especial", "Campanha"],
    ]);
  });

  it("extrai apenas campanhas CMP e calcula KPIs ponderados a partir dos registros", () => {
    const campaigns = parseCampaignCsv(sampleCsv);
    expect(campaigns).toHaveLength(2);
    expect(campaigns[0].campaign).toBe("Campanha, especial");
    expect(campaigns[0].clicks).toBe(28000);
    expect(campaigns[0].conversionRate).toBeCloseTo(0.042);

    const kpis = calculateKpis(campaigns);
    expect(kpis.campaigns).toBe(2);
    expect(kpis.clicks).toBe(29000);
    expect(kpis.orders).toBe(1196);
    expect(kpis.grossRevenue).toBe(339280);
    expect(kpis.investment).toBeCloseTo(84988.32);
    expect(kpis.netProfit).toBeCloseTo(208778.08);
    expect(kpis.roas).toBeCloseTo(339280 / 84988.32);
    expect(kpis.roiPercent).toBeCloseTo((208778.08 / 84988.32) * 100);
    expect(kpis.conversionRate).toBeCloseTo((1196 / 29000) * 100);
  });
});
