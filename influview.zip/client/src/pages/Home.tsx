import { useCallback, useEffect, useMemo, useState } from "react";
import {
  ArrowDownToLine,
  ArrowUpRight,
  BarChart3,
  ChevronDown,
  CircleAlert,
  ExternalLink,
  FilterX,
  Maximize2,
  RefreshCw,
  Search,
  ShieldCheck,
  Sparkles,
  Target,
  TrendingUp,
  UsersRound,
} from "lucide-react";
import {
  Bar,
  BarChart,
  CartesianGrid,
  Cell,
  ReferenceLine,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";
import {
  calculateKpis,
  fetchCampaigns,
  groupCampaigns,
  SHEET_URL,
  type Campaign,
  type DashboardKpis,
} from "@/lib/sheets";
import {
  exportCampaignCsv,
  exportCampaignPdf,
  exportCampaignXlsx,
} from "@/lib/exports";

const currency0 = new Intl.NumberFormat("pt-BR", {
  style: "currency",
  currency: "BRL",
  maximumFractionDigits: 0,
});
const currency2 = new Intl.NumberFormat("pt-BR", {
  style: "currency",
  currency: "BRL",
  minimumFractionDigits: 2,
  maximumFractionDigits: 2,
});
const compactCurrency = new Intl.NumberFormat("pt-BR", {
  style: "currency",
  currency: "BRL",
  notation: "compact",
  maximumFractionDigits: 1,
});
const number = new Intl.NumberFormat("pt-BR", { maximumFractionDigits: 0 });
const percent1 = new Intl.NumberFormat("pt-BR", { maximumFractionDigits: 1 });
const percent2 = new Intl.NumberFormat("pt-BR", { maximumFractionDigits: 2 });

const emptyKpis: DashboardKpis = {
  campaigns: 0,
  clicks: 0,
  orders: 0,
  units: 0,
  grossRevenue: 0,
  netRevenue: 0,
  investment: 0,
  netProfit: 0,
  roas: 0,
  roiPercent: 0,
  conversionRate: 0,
  averageTicket: 0,
};

function unique(campaigns: Campaign[], field: keyof Campaign): string[] {
  return Array.from(
    new Set(
      campaigns
        .map(campaign => String(campaign[field] ?? "").trim())
        .filter(Boolean)
    )
  ).sort((a, b) => a.localeCompare(b, "pt-BR"));
}

function timeLabel(value: Date | null) {
  if (!value) return "Aguardando a primeira leitura";
  return `Consultado às ${value.toLocaleTimeString("pt-BR", { hour: "2-digit", minute: "2-digit" })}`;
}

function compactLabel(value: string, max = 24) {
  return value.length > max ? `${value.slice(0, max - 1)}…` : value;
}

function decisionTone(value: string) {
  if (/escalar/i.test(value)) return "decision decision--scale";
  if (/manter|renovar/i.test(value)) return "decision decision--keep";
  if (/otimizar/i.test(value)) return "decision decision--optimize";
  if (/encerrar/i.test(value)) return "decision decision--stop";
  return "decision";
}

type SelectFilterProps = {
  label: string;
  value: string;
  options: string[];
  onChange: (value: string) => void;
};

function SelectFilter({ label, value, options, onChange }: SelectFilterProps) {
  return (
    <label className="filter-field">
      <span>{label}</span>
      <select value={value} onChange={event => onChange(event.target.value)}>
        <option value="">Todos</option>
        {options.map(option => (
          <option value={option} key={option}>
            {option}
          </option>
        ))}
      </select>
      <ChevronDown aria-hidden="true" size={15} />
    </label>
  );
}

function MetricCard({
  label,
  value,
  detail,
  icon,
  featured = false,
}: {
  label: string;
  value: string;
  detail: string;
  icon: React.ReactNode;
  featured?: boolean;
}) {
  return (
    <article
      className={`metric-card${featured ? " metric-card--featured" : ""}`}
    >
      <div className="metric-card__top">
        <span className="metric-card__label">{label}</span>
        <span className="metric-card__icon">{icon}</span>
      </div>
      <p className="metric-card__value">{value}</p>
      <p className="metric-card__detail">{detail}</p>
    </article>
  );
}

function ChartTooltip({ active, payload, label }: any) {
  if (!active || !payload?.length) return null;
  const item = payload[0];
  const isRoi = item.dataKey === "roiPercent";
  return (
    <div className="chart-tooltip">
      <strong>{label}</strong>
      <span>
        {isRoi
          ? `${percent1.format(Number(item.value))}% de ROI líquido`
          : currency2.format(Number(item.value))}
      </span>
    </div>
  );
}

export default function Home() {
  const [campaigns, setCampaigns] = useState<Campaign[]>([]);
  const [lastSync, setLastSync] = useState<Date | null>(null);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [query, setQuery] = useState("");
  const [influencer, setInfluencer] = useState("");
  const [format, setFormat] = useState("");
  const [profile, setProfile] = useState("");
  const [gym, setGym] = useState("");
  const [brand, setBrand] = useState("");
  const [recommendation, setRecommendation] = useState("");
  const [presentationMode, setPresentationMode] = useState(false);
  const [exportOpen, setExportOpen] = useState(false);
  const [mobileExportOpen, setMobileExportOpen] = useState(false);
  const [exportingFormat, setExportingFormat] = useState<
    "csv" | "xlsx" | "pdf" | null
  >(null);

  const refresh = useCallback(async (quiet = false) => {
    if (quiet) setRefreshing(true);
    else setLoading(true);
    try {
      const nextCampaigns = await fetchCampaigns();
      setCampaigns(nextCampaigns);
      setLastSync(new Date());
      setError(null);
    } catch (caught) {
      setError(
        caught instanceof Error
          ? caught.message
          : "Falha ao consultar a planilha."
      );
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  }, []);

  useEffect(() => {
    void refresh();
    const interval = window.setInterval(() => void refresh(true), 60_000);
    return () => window.clearInterval(interval);
  }, [refresh]);

  useEffect(() => {
    const syncFullscreen = () =>
      setPresentationMode(Boolean(document.fullscreenElement));
    document.addEventListener("fullscreenchange", syncFullscreen);
    return () =>
      document.removeEventListener("fullscreenchange", syncFullscreen);
  }, []);

  const filtered = useMemo(() => {
    const normalizedQuery = query.trim().toLocaleLowerCase("pt-BR");
    return campaigns.filter(campaign => {
      const matchesText =
        !normalizedQuery ||
        campaign.influencer
          .toLocaleLowerCase("pt-BR")
          .includes(normalizedQuery) ||
        campaign.campaign
          .toLocaleLowerCase("pt-BR")
          .includes(normalizedQuery) ||
        campaign.id.toLocaleLowerCase("pt-BR").includes(normalizedQuery);
      return (
        matchesText &&
        (!influencer || campaign.influencer === influencer) &&
        (!format || campaign.format === format) &&
        (!profile || campaign.profile === profile) &&
        (!gym || campaign.gym === gym) &&
        (!brand || campaign.brand === brand) &&
        (!recommendation || campaign.recommendation === recommendation)
      );
    });
  }, [
    campaigns,
    query,
    influencer,
    format,
    profile,
    gym,
    brand,
    recommendation,
  ]);

  const kpis = useMemo(
    () => (filtered.length ? calculateKpis(filtered) : emptyKpis),
    [filtered]
  );
  const byFormat = useMemo(
    () => groupCampaigns(filtered, "format"),
    [filtered]
  );
  const byInfluencer = useMemo(
    () => groupCampaigns(filtered, "influencer"),
    [filtered]
  );
  const revenueChart = useMemo(
    () =>
      [...byFormat].sort((a, b) => b.grossRevenue - a.grossRevenue).slice(0, 6),
    [byFormat]
  );
  const roiChart = useMemo(
    () => [...byFormat].sort((a, b) => a.roiPercent - b.roiPercent),
    [byFormat]
  );
  const topFormat = useMemo(
    () => [...byFormat].sort((a, b) => b.grossRevenue - a.grossRevenue)[0],
    [byFormat]
  );
  const bestRoiFormat = useMemo(
    () => [...byFormat].sort((a, b) => b.roiPercent - a.roiPercent)[0],
    [byFormat]
  );
  const topCreator = useMemo(
    () => [...byInfluencer].sort((a, b) => b.grossRevenue - a.grossRevenue)[0],
    [byInfluencer]
  );
  const filteredSorted = useMemo(
    () => [...filtered].sort((a, b) => b.grossRevenue - a.grossRevenue),
    [filtered]
  );

  const hasFilters = Boolean(
    query || influencer || format || profile || gym || brand || recommendation
  );
  const resetFilters = () => {
    setQuery("");
    setInfluencer("");
    setFormat("");
    setProfile("");
    setGym("");
    setBrand("");
    setRecommendation("");
  };

  const downloadAs = async (kind: "csv" | "xlsx" | "pdf") => {
    setExportingFormat(kind);
    try {
      if (kind === "csv") exportCampaignCsv(filteredSorted);
      if (kind === "xlsx") await exportCampaignXlsx(filteredSorted, kpis);
      if (kind === "pdf") await exportCampaignPdf(filteredSorted, kpis);
    } catch {
      window.alert("Não foi possível gerar esse arquivo. Tente novamente.");
    } finally {
      setExportingFormat(null);
      setExportOpen(false);
      setMobileExportOpen(false);
    }
  };

  const togglePresentation = async () => {
    try {
      if (document.fullscreenElement) await document.exitFullscreen();
      else await document.documentElement.requestFullscreen();
    } catch {
      setPresentationMode(current => !current);
    }
  };

  if (loading && campaigns.length === 0) {
    return (
      <main className="app-shell app-shell--loading">
        <div className="loading-brand">
          <span className="brand-mark">
            <BarChart3 size={18} />
          </span>{" "}
          PULSO <i> / PERFORMANCE</i>
        </div>
        <div className="loading-panel">
          <span className="spinner" />
          <p>Conectando à planilha publicada…</p>
          <span>
            Buscando os dados mais recentes para montar a visão executiva.
          </span>
        </div>
      </main>
    );
  }

  if (campaigns.length === 0 && error) {
    return (
      <main className="app-shell app-shell--loading">
        <div className="loading-brand">
          <span className="brand-mark">
            <BarChart3 size={18} />
          </span>{" "}
          PULSO <i> / PERFORMANCE</i>
        </div>
        <div className="error-panel">
          <span className="error-panel__icon">
            <CircleAlert size={22} />
          </span>
          <p className="eyebrow">FONTE NÃO DISPONÍVEL</p>
          <h1>Não conseguimos ler a planilha.</h1>
          <p>{error}</p>
          <button
            className="button button--dark"
            onClick={() => void refresh()}
          >
            <RefreshCw size={15} /> Tentar novamente
          </button>
          <a href={SHEET_URL} target="_blank" rel="noreferrer">
            Abrir planilha original <ExternalLink size={14} />
          </a>
        </div>
      </main>
    );
  }

  return (
    <main
      className={`app-shell${presentationMode ? " app-shell--presentation" : ""}`}
    >
      <div className="dashboard-wrap">
        <header className="topbar">
          <a
            className="brand"
            href="#top"
            aria-label="Pulso Performance, início"
          >
            <span className="brand-mark">
              <BarChart3 size={18} strokeWidth={2.4} />
            </span>
            <span className="brand-word">
              PULSO <i>/ PERFORMANCE</i>
            </span>
          </a>
          <div className="topbar__right">
            <span
              className={`sync-status${error ? " sync-status--warning" : ""}`}
            >
              <span className="sync-dot" />
              {error ? "Última leitura mantida" : "Fonte conectada"}
            </span>
            <a
              className="button button--outline source-link"
              href={SHEET_URL}
              target="_blank"
              rel="noreferrer"
            >
              <span>Abrir planilha</span>
              <ExternalLink size={14} />
            </a>
            <button
              className="button button--outline refresh-button"
              onClick={() => void refresh(true)}
              disabled={refreshing}
            >
              <RefreshCw size={15} className={refreshing ? "spin" : ""} />
              <span>{refreshing ? "Atualizando" : "Atualizar"}</span>
            </button>
            <div className={`export-menu${exportOpen ? " is-open" : ""}`}>
              <button
                className="button button--dark export-menu__trigger"
                aria-expanded={exportOpen}
                onClick={() => setExportOpen(open => !open)}
                disabled={filtered.length === 0 || exportingFormat !== null}
              >
                <ArrowDownToLine size={15} />
                <span>{exportingFormat ? "Preparando…" : "Exportar"}</span>
                <ChevronDown size={14} />
              </button>
              {exportOpen && (
                <div className="export-menu__panel">
                  <p>
                    {exportingFormat
                      ? "GERANDO ARQUIVO…"
                      : "BAIXAR RECORTE ATUAL"}
                  </p>
                  <button
                    disabled={exportingFormat !== null}
                    onClick={() => void downloadAs("csv")}
                  >
                    <span className="file-badge file-badge--csv">CSV</span>
                    <span>
                      Dados completos<small>Planilha filtrada em CSV</small>
                    </span>
                  </button>
                  <button
                    disabled={exportingFormat !== null}
                    onClick={() => void downloadAs("xlsx")}
                  >
                    <span className="file-badge file-badge--xls">XLSX</span>
                    <span>
                      Excel + resumo<small>Campanhas e KPIs em abas</small>
                    </span>
                  </button>
                  <button
                    disabled={exportingFormat !== null}
                    onClick={() => void downloadAs("pdf")}
                  >
                    <span className="file-badge file-badge--pdf">PDF</span>
                    <span>
                      Relatório executivo
                      <small>Visão pronta para compartilhar</small>
                    </span>
                  </button>
                </div>
              )}
            </div>
            <button
              className="icon-button presentation-button"
              onClick={() => void togglePresentation()}
              aria-label={
                presentationMode ? "Sair da tela cheia" : "Modo apresentação"
              }
              title="Modo apresentação"
            >
              <Maximize2 size={17} />
            </button>
          </div>
        </header>

        <section className="hero" id="top">
          <div className="hero__copy">
            <p className="eyebrow">
              <span className="eyebrow-line" /> INTELIGÊNCIA DE CAMPANHAS{" "}
              <span className="hero__year">DADOS PUBLICADOS</span>
            </p>
            <h1>
              Marketing de influência,
              <br />
              <em>resultado em foco.</em>
            </h1>
            <p className="hero__description">
              Acompanhe vendas, retorno e eficiência das campanhas em uma visão
              única.
            </p>
          </div>
          <div className="hero__meta">
            <span className="hero__meta-label">
              <span
                className={`status-orb${error ? " status-orb--warning" : ""}`}
              />{" "}
              {error ? "ATUALIZAÇÃO PAUSADA" : "SINCRONIZAÇÃO AUTOMÁTICA"}
            </span>
            <strong>{timeLabel(lastSync)}</strong>
            <span className="hero__meta-note">
              Consulta a cada 1 minuto <span>·</span> {campaigns.length}{" "}
              campanhas na fonte
            </span>
            <span className="hero__meta-note hero__meta-note--muted">
              {error
                ? "Falha ao consultar; exibindo os últimos dados carregados."
                : "Os números acompanham as alterações publicadas na planilha."}
            </span>
          </div>
        </section>

        {error && (
          <div className="connection-notice" role="status">
            <CircleAlert size={16} />
            <span>
              Não foi possível atualizar agora. Mantivemos na tela a última
              leitura válida.
            </span>
            <button onClick={() => void refresh(true)}>Tentar de novo</button>
          </div>
        )}

        <section className="kpi-grid" aria-label="Indicadores executivos">
          <MetricCard
            label="Faturamento bruto"
            value={currency0.format(kpis.grossRevenue)}
            detail={`${number.format(kpis.campaigns)} campanhas no recorte`}
            icon={<TrendingUp size={17} />}
          />
          <MetricCard
            label="Investimento total"
            value={currency0.format(kpis.investment)}
            detail="Cachês, produtos, produção e comissões"
            icon={<ArrowDownToLine size={16} />}
          />
          <MetricCard
            label="Lucro líquido"
            value={currency0.format(kpis.netProfit)}
            detail={`Receita líquida ${currency0.format(kpis.netRevenue)}`}
            icon={<Sparkles size={17} />}
          />
          <MetricCard
            label="ROAS consolidado"
            value={`${kpis.roas.toLocaleString("pt-BR", { minimumFractionDigits: 2, maximumFractionDigits: 2 })}x`}
            detail="Receita bruta por R$ 1 investido"
            icon={<Target size={17} />}
          />
          <MetricCard
            label="ROI líquido"
            value={`${percent1.format(kpis.roiPercent)}%`}
            detail="Retorno líquido sobre o investimento"
            icon={<ArrowUpRight size={17} />}
            featured
          />
        </section>

        <section className="secondary-metrics" aria-label="Métricas de volume">
          <div className="secondary-metrics__intro">
            <span>VOLUME DA OPERAÇÃO</span>
            <i />
          </div>
          <div className="secondary-metric">
            <span>Cliques no link</span>
            <strong>{number.format(kpis.clicks)}</strong>
          </div>
          <div className="secondary-metric">
            <span>Pedidos realizados</span>
            <strong>{number.format(kpis.orders)}</strong>
          </div>
          <div className="secondary-metric">
            <span>Conversão ponderada</span>
            <strong>{percent2.format(kpis.conversionRate)}%</strong>
          </div>
          <div className="secondary-metric">
            <span>Ticket médio bruto</span>
            <strong>{currency2.format(kpis.averageTicket)}</strong>
          </div>
          <div className="secondary-metric">
            <span>Unidades vendidas</span>
            <strong>{number.format(kpis.units)}</strong>
          </div>
        </section>

        <section
          className="analysis-section"
          aria-label="Análise de desempenho por formato"
        >
          <div className="section-heading">
            <div>
              <p className="eyebrow">LEITURA DE PERFORMANCE</p>
              <h2>Onde o resultado acontece</h2>
            </div>
            <span className="section-heading__aside">
              <UsersRound size={15} /> Comparativo por formato de mídia
            </span>
          </div>
          <div className="chart-grid">
            <article className="surface chart-card">
              <div className="card-heading">
                <div>
                  <span className="card-kicker">ESCALA</span>
                  <h3>Faturamento por formato</h3>
                  <p>Receita bruta agrupada pelo canal de mídia</p>
                </div>
                <span className="chart-icon">
                  <BarChart3 size={17} />
                </span>
              </div>
              {revenueChart.length ? (
                <div className="chart-area">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart
                      data={revenueChart}
                      layout="vertical"
                      margin={{ top: 4, right: 30, bottom: 0, left: 0 }}
                      barCategoryGap={12}
                    >
                      <CartesianGrid horizontal={false} stroke="#e9eee9" />
                      <XAxis type="number" hide />
                      <YAxis
                        type="category"
                        dataKey="name"
                        width={154}
                        axisLine={false}
                        tickLine={false}
                        tick={{ fill: "#67716b", fontSize: 10 }}
                        tickFormatter={(value: string) =>
                          compactLabel(value, 26)
                        }
                      />
                      <Tooltip
                        content={<ChartTooltip />}
                        cursor={{ fill: "#f0f4ef" }}
                      />
                      <Bar
                        dataKey="grossRevenue"
                        name="Faturamento bruto"
                        fill="#35695a"
                        radius={[0, 5, 5, 0]}
                        maxBarSize={22}
                      >
                        {revenueChart.map(item => (
                          <Cell
                            key={item.name}
                            fill={
                              item.name === topFormat?.name
                                ? "#35695a"
                                : "#a3b9aa"
                            }
                          />
                        ))}
                      </Bar>
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              ) : (
                <div className="chart-empty">
                  Sem resultados para os filtros selecionados.
                </div>
              )}
              <div className="chart-footnote">
                <span className="legend-dot legend-dot--green" /> Faturamento
                bruto{" "}
                <span className="chart-footnote__right">
                  {revenueChart.length} formatos
                </span>
              </div>
            </article>

            <article className="surface chart-card">
              <div className="card-heading">
                <div>
                  <span className="card-kicker">EFICIÊNCIA</span>
                  <h3>ROI líquido por formato</h3>
                  <p>Retorno sobre investimento após custos</p>
                </div>
                <span className="chart-icon chart-icon--lime">
                  <Target size={17} />
                </span>
              </div>
              {roiChart.length ? (
                <div className="chart-area">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart
                      data={roiChart}
                      layout="vertical"
                      margin={{ top: 4, right: 34, bottom: 0, left: 0 }}
                      barCategoryGap={12}
                    >
                      <CartesianGrid horizontal={false} stroke="#e9eee9" />
                      <XAxis
                        type="number"
                        hide
                        domain={[
                          (dataMin: number) => Math.min(0, dataMin - 25),
                          (dataMax: number) => dataMax + 25,
                        ]}
                      />
                      <YAxis
                        type="category"
                        dataKey="name"
                        width={154}
                        axisLine={false}
                        tickLine={false}
                        tick={{ fill: "#67716b", fontSize: 10 }}
                        tickFormatter={(value: string) =>
                          compactLabel(value, 26)
                        }
                      />
                      <ReferenceLine
                        x={0}
                        stroke="#77827b"
                        strokeDasharray="3 3"
                      />
                      <Tooltip
                        content={<ChartTooltip />}
                        cursor={{ fill: "#f0f4ef" }}
                      />
                      <Bar
                        dataKey="roiPercent"
                        name="ROI líquido"
                        radius={[0, 5, 5, 0]}
                        maxBarSize={22}
                      >
                        {roiChart.map(item => (
                          <Cell
                            key={item.name}
                            fill={
                              item.roiPercent < 0
                                ? "#d66a5f"
                                : item.name === bestRoiFormat?.name
                                  ? "#a4c647"
                                  : "#9bb8a8"
                            }
                          />
                        ))}
                      </Bar>
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              ) : (
                <div className="chart-empty">
                  Sem resultados para os filtros selecionados.
                </div>
              )}
              <div className="chart-footnote">
                <span className="legend-dot legend-dot--lime" /> ROI líquido{" "}
                <span className="chart-footnote__right">
                  {roiChart.filter(item => item.roiPercent < 0).length} abaixo
                  de zero
                </span>
              </div>
            </article>
          </div>

          <div className="insight-strip">
            <div className="insight-strip__label">
              <span className="insight-spark">
                <Sparkles size={15} />
              </span>
              <div>
                <b>DESTAQUES DO RECORTE</b>
                <span>Calculados a partir das campanhas filtradas</span>
              </div>
            </div>
            <div className="insight-item">
              <span>Maior faturamento por formato</span>
              <strong>
                {topFormat ? compactLabel(topFormat.name, 30) : "—"}
              </strong>
              <small>
                {topFormat
                  ? currency0.format(topFormat.grossRevenue)
                  : "Sem dados"}
              </small>
            </div>
            <div className="insight-item">
              <span>Maior ROI por formato</span>
              <strong>
                {bestRoiFormat ? compactLabel(bestRoiFormat.name, 30) : "—"}
              </strong>
              <small>
                {bestRoiFormat
                  ? `${percent1.format(bestRoiFormat.roiPercent)}% de ROI líquido`
                  : "Sem dados"}
              </small>
            </div>
            <div className="insight-item insight-item--creator">
              <span>Influenciador com maior receita</span>
              <strong>
                {topCreator ? compactLabel(topCreator.name, 32) : "—"}
              </strong>
              <small>
                {topCreator
                  ? currency0.format(topCreator.grossRevenue)
                  : "Sem dados"}
              </small>
            </div>
          </div>
        </section>

        <section className="campaign-section" aria-label="Campanhas e filtros">
          <div className="section-heading section-heading--table">
            <div>
              <p className="eyebrow">DETALHAMENTO</p>
              <h2>Campanhas e vendas</h2>
              <p className="section-subtitle">
                Explore os dados e compare o retorno de cada iniciativa.
              </p>
            </div>
            <span className="result-count">
              <b>{filtered.length}</b> de {campaigns.length} campanhas
            </span>
          </div>

          <div className="surface filter-panel">
            <div className="filter-panel__header">
              <span className="filter-panel__title">
                <Search size={15} /> FILTRAR DADOS
              </span>
              {hasFilters && (
                <button className="clear-filters" onClick={resetFilters}>
                  <FilterX size={14} /> Limpar filtros
                </button>
              )}
            </div>
            <div className="filter-row">
              <label className="search-field">
                <Search size={15} />
                <input
                  value={query}
                  onChange={event => setQuery(event.target.value)}
                  placeholder="Busque campanha, código ou influenciador"
                  aria-label="Buscar campanha, código ou influenciador"
                />
              </label>
              <SelectFilter
                label="Influenciador"
                value={influencer}
                options={unique(campaigns, "influencer")}
                onChange={setInfluencer}
              />
              <SelectFilter
                label="Formato"
                value={format}
                options={unique(campaigns, "format")}
                onChange={setFormat}
              />
              <SelectFilter
                label="Perfil"
                value={profile}
                options={unique(campaigns, "profile")}
                onChange={setProfile}
              />
              <SelectFilter
                label="Rede"
                value={gym}
                options={unique(campaigns, "gym")}
                onChange={setGym}
              />
              <SelectFilter
                label="Marca"
                value={brand}
                options={unique(campaigns, "brand")}
                onChange={setBrand}
              />
              <SelectFilter
                label="Recomendação"
                value={recommendation}
                options={unique(campaigns, "recommendation")}
                onChange={setRecommendation}
              />
            </div>
            <p className="filter-note">
              <ShieldCheck size={13} /> Filtros usam somente os campos
              disponíveis na planilha; a fonte não possui coluna de data.
            </p>
          </div>

          <div className="surface table-card">
            <div className="table-card__heading">
              <div>
                <h3>Desempenho por campanha</h3>
                <span>
                  Valores da planilha publicada · ordenado por faturamento bruto
                </span>
              </div>
              <span className="table-card__total">
                {number.format(filtered.length)} registros
              </span>
            </div>
            {filteredSorted.length > 0 ? (
              <div className="table-scroll">
                <table>
                  <thead>
                    <tr>
                      <th>INFLUENCIADOR / CAMPANHA</th>
                      <th>FORMATO</th>
                      <th>FATURAMENTO</th>
                      <th>INVESTIMENTO</th>
                      <th>LUCRO LÍQUIDO</th>
                      <th>ROAS</th>
                      <th>ROI</th>
                      <th>DECISÃO</th>
                    </tr>
                  </thead>
                  <tbody>
                    {filteredSorted.map(campaign => (
                      <tr key={campaign.id}>
                        <td className="campaign-cell">
                          <span className="campaign-cell__id">
                            {campaign.id}
                          </span>
                          <strong>{campaign.influencer}</strong>
                          <small>{campaign.campaign}</small>
                        </td>
                        <td>
                          <span className="format-cell">{campaign.format}</span>
                        </td>
                        <td className="money-cell">
                          {currency2.format(campaign.grossRevenue)}
                        </td>
                        <td className="money-cell money-cell--muted">
                          {currency2.format(campaign.investment)}
                        </td>
                        <td
                          className={`money-cell${campaign.netProfit < 0 ? " money-cell--negative" : " money-cell--positive"}`}
                        >
                          {currency2.format(campaign.netProfit)}
                        </td>
                        <td>
                          <span className="roas-value">
                            {campaign.roas.toLocaleString("pt-BR", {
                              minimumFractionDigits: 2,
                              maximumFractionDigits: 2,
                            })}
                            x
                          </span>
                        </td>
                        <td>
                          <span
                            className={`roi-pill${campaign.roiPercent < 0 ? " roi-pill--negative" : ""}`}
                          >
                            {percent1.format(campaign.roiPercent)}%
                          </span>
                        </td>
                        <td>
                          <span
                            className={decisionTone(campaign.recommendation)}
                          >
                            {campaign.recommendation || "Sem indicação"}
                          </span>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            ) : (
              <div className="empty-table">
                <span>
                  <Search size={19} />
                </span>
                <strong>Nenhuma campanha encontrada</strong>
                <p>Remova alguns filtros ou tente outra busca.</p>
                <button
                  className="button button--outline"
                  onClick={resetFilters}
                >
                  Limpar filtros
                </button>
              </div>
            )}
            <div className="table-card__footer">
              <span>KPIs e gráficos refletem os filtros selecionados.</span>
              <button onClick={() => void refresh(true)} disabled={refreshing}>
                <RefreshCw size={13} className={refreshing ? "spin" : ""} />{" "}
                {refreshing ? "Atualizando dados" : "Atualizar dados"}
              </button>
            </div>
          </div>
        </section>

        <footer className="footer">
          <a className="brand brand--footer" href="#top">
            <span className="brand-mark">
              <BarChart3 size={15} />
            </span>
            <span className="brand-word">
              PULSO <i>/ PERFORMANCE</i>
            </span>
          </a>
          <span>Dados conectados à publicação do Google Sheets</span>
          <a href={SHEET_URL} target="_blank" rel="noreferrer">
            Fonte original <ExternalLink size={12} />
          </a>
        </footer>
      </div>

      <div className="mobile-export">
        <button
          className="button button--dark"
          onClick={() => setMobileExportOpen(open => !open)}
          aria-expanded={mobileExportOpen}
          disabled={exportingFormat !== null}
        >
          <ArrowDownToLine size={16} />{" "}
          {exportingFormat ? "Preparando arquivo…" : "Exportar recorte"}{" "}
          <ChevronDown size={15} />
        </button>
        {mobileExportOpen && (
          <div className="mobile-export__options">
            <button
              disabled={exportingFormat !== null}
              onClick={() => void downloadAs("csv")}
            >
              CSV
            </button>
            <button
              disabled={exportingFormat !== null}
              onClick={() => void downloadAs("xlsx")}
            >
              Excel XLSX
            </button>
            <button
              disabled={exportingFormat !== null}
              onClick={() => void downloadAs("pdf")}
            >
              Relatório PDF
            </button>
          </div>
        )}
      </div>
    </main>
  );
}
