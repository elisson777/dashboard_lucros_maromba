# TODO — Dashboard de Marketing de Influência e Afiliados

- [ ] Visão executiva e indicadores para apresentação: manter os KPIs legíveis e recalculá-los sobre os 45 registros da nova base ou sobre os filtros selecionados; exibir o consolidado do trimestre Set/26–Nov/26.
- [ ] Análises, filtros e tabela baseados na fonte: apresentar gráficos e tabelas para comparar resultados por influenciador, formato e outras dimensões; incluir filtro de período baseado em “Mês / Período” com opção de trimestre completo e seleções Set/26, Out/26 e Nov/26; contar somente registros CMP- e ignorar a linha consolidada para não duplicar os totais.
- [ ] Atualização conectada à nova planilha: usar a aba “Base de Campanhas e Vendas” do arquivo enviado; quando a planilha mudar, refletir as alterações na dashboard a cada minuto e manualmente; exibir carregamento, última atualização, ausência de dados e falhas.
- [ ] Exportação e acesso à origem: manter opções CSV, XLSX e PDF para o recorte visualizado; atualizar o link direto e destacado para a nova planilha do Google Sheets.
- [x] Apresentação e acessibilidade de uso: manter layout responsivo e adequado para tela grande em apresentações, desktop e celular.
